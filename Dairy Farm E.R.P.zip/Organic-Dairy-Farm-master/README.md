# Organic-Dairy-Farm
Install Python and Django for the project


The site handles all the Cattle information along with its vaccination records and health status, it also have  the details of the calf. People can also order Milk and a receipt will be generated accordingly.
