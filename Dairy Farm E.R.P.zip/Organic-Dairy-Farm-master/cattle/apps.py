from django.apps import AppConfig


class CattleConfig(AppConfig):
    name = 'cattle'
